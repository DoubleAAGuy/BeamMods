--Created by Inn0centJok3r
--DO NOT USE WITHOUT PERMISSION! ASK ME AT https://www.beamng.com/members/inn0centjok3r.318168/
local M = {}
local device = nil
local SafetySwitch = false

local function onInit()
  if electrics.values["isSimpleTrafficCar"] then
	M.updateGFX = nop
	M.onReset = nop
	return
  end
    device = powertrain.getDevice("mainEngine")
end

local function onReset()
	SafetySwitch = false
end

local function updateGFX(dt) 
--------
--Created by Inn0centJok3r


  if device == nil then return end -- prevent lua error when engine removed
	if device.maxTorqueRating == nil then return --prevent lua error from electric engine 
	end
  if device.maxTorqueRating > 0 then
	if device.combustionTorque > device.maxTorqueRating then 
		SafetySwitch = true
	end
	if SafetySwitch then  
		--device.maxTorqueRating = 50
		guihooks.message("Reached Torque Limit! Limp Mode activated!", 1, "vehicle.damage.mildOverrev")


		--Method call 
		
       electrics.values.throttle = electrics.values.throttle * 0.2 

	
       --combustionEngine.maxRPM = combustionEngine.maxRPM * 0.5
	   
	


	end

	if  electrics.values.ignitionLevel == 0 then
		SafetySwitch = false


	end


  end
end
-- public interface
M.onInit = onInit
M.onReset = onReset
M.updateGFX = updateGFX

return M